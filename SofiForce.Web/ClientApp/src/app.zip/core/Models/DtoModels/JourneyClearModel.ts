export class JourneyClearModel {
    clearDate: Date | null;
}