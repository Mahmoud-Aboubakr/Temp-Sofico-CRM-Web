export class supplementaryUploadDtoModel {
    filePath: string;
    validCount: number;
    inValidCount: number;
    errors: string[];
}