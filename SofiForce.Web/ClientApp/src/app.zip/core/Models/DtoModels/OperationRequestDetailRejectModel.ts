export class OperationRequestDetailRejectModel {
    detailId: number;
    accuracy: number;
    operationRejectReasonId:number;
    operationTypeId:number;

}