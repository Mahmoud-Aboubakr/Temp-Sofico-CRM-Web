export interface JourneyUploadModel {
    filePath: string;
    uploadDate: Date | null;
}