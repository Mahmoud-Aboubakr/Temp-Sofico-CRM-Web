export class FileModel {
    fileUrl: string;
    directory: string;
    fileName: string;
    fileSize: number;
}