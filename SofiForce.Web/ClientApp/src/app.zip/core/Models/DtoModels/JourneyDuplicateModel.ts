export interface JourneyDuplicateModel {

}