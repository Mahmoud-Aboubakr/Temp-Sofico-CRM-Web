export class LookupModel {
    id:number;
    code:string;
    name:string;
}
