export interface AppSetting {
    ver: string;
}