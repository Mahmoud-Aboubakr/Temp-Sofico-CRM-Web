export interface ListNumberDto {
    ids: number[];
}