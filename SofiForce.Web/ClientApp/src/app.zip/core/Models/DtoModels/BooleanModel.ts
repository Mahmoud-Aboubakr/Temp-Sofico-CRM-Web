export interface BooleanModel {
    status: boolean;
}