export class ClientPlanClearModel {
    clearDate: Date | null;
}