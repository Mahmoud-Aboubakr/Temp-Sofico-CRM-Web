export class GeoPoint {
    lat: number;
    lng: number;
    label:string;
    id:number;

}