export class OperationRequestDetailCodedModel {
    detailId: number;
    clientId: number;
    operationTypeId:number;

}