export interface UploadModel {
    filePath: string;
}