export class OperationRequestDetailApproveModel {
    detailId: number;
    accuracy: number;
    operationTypeId:number;
}