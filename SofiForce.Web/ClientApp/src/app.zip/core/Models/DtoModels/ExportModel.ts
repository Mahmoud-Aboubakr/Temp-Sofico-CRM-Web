export class ExportModel {
    total: number;
    fileUrl: string;
}