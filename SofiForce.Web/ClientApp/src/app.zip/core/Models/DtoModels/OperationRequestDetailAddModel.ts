export interface OperationRequestDetailAddModel {
    operationId: number;
    clientId: number
    clientCode: string;
}