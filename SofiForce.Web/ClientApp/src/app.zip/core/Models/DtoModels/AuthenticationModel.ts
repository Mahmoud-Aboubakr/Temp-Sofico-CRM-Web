export interface AuthenticationModel {
    client: string;
    userName: string;
    password: string;
}