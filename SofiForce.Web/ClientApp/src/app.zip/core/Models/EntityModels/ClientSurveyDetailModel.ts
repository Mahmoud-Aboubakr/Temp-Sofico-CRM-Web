export interface ClientSurveyDetailModel {
    clientDetailId: number;
    detailAnswerId: number | null;
    isSelected: boolean | null;
}