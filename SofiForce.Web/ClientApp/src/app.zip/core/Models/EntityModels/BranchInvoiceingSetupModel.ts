export class BranchInvoiceingSetupModel {
    setupId: number;
    branchId: number | null;
    isEnabled: boolean | null;
    serviceWorkerId: number | null;
}