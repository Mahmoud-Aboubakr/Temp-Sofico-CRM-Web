export class AppUserClientGroupModel {
    appUserGroupId: number;
    userId: number | null;
    clientGroupId: number | null;
}