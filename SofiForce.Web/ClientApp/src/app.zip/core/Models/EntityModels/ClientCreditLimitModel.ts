export class ClientCreditLimitModel {
    limitId: number;
}