
export class RepresentativeJourneyModel {
    routeId: number | null;
    representativeId: number | null;
}