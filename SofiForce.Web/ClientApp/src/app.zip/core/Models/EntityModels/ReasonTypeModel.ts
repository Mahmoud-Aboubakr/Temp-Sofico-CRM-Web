export interface ReasonTypeModel {
    reasonTypeId: number;
    reasonTypeCode: string;
    reasonTypeName: string;
}