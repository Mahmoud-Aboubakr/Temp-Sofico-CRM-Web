export class PromtionCriteriaSalesManAttrCustomModel {
    salesManCustomId: number;
    salesManAttributeId: number | null;
    valueFrom: string;
  
    isActive:boolean;
    cBy: number | null;
    cDate: Date | null;
    eBy: number | null;
    eDate: Date | null;
}