export interface WebSetting {
    ver: string;
}