export interface SalesOrderMessagesModel {
    salesMessageId: number | null;
    salesId: number | null;
    userId: number | null;
    messageDate: Date | null;
    message: string;
}