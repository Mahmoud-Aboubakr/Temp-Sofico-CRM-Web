export interface DashboardTimelineModel {
    lineValue: number;
    lineTarget: number;
    lineLabel: number;
}