import { BaseSearchModel } from "./baseSearchModel";

export interface LocationLevelSearchModel extends BaseSearchModel {
   
}