import { BaseSearchModel } from "./baseSearchModel";

export interface GovernerateSearchModel extends BaseSearchModel {
   
}