import { BaseSearchModel } from "./baseSearchModel";

export interface SalesOrderErrorSearchModel extends BaseSearchModel {
    salesId: number | 0;
}