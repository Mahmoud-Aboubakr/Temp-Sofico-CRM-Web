import { BaseSearchModel } from "./baseSearchModel";

export interface CitySearchModel extends BaseSearchModel {
   
}