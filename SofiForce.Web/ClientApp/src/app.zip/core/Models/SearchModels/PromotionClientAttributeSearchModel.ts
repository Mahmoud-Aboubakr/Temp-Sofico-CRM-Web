import { BaseSearchModel } from "./baseSearchModel";

export interface PromotionClientAttributeSearchModel extends BaseSearchModel {

}