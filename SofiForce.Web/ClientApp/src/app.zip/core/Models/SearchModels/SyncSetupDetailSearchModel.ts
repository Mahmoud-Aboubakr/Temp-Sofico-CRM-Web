import { BaseSearchModel } from "./baseSearchModel";

export interface SyncSetupDetailSearchModel extends BaseSearchModel {
    setupId: number | null;
}