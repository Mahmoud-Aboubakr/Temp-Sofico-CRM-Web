import { BaseSearchModel } from "./baseSearchModel";

export interface ItemGroupSearchModel extends BaseSearchModel {

}