import { BaseSearchModel } from "./baseSearchModel";

export interface PaymentTermSearchModel extends BaseSearchModel {
   
}