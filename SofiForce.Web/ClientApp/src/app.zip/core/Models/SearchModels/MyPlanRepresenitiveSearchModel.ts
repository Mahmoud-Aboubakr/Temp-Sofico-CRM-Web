import { BaseSearchModel } from "./baseSearchModel";

export interface MyPlanSearchModel extends BaseSearchModel {
    
}