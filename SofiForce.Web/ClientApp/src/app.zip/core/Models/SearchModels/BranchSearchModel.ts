import { BaseSearchModel } from "./baseSearchModel";

export interface BranchSearchModel extends BaseSearchModel {

}