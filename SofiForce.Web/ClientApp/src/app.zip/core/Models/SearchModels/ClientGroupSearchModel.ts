import { BaseSearchModel } from "./baseSearchModel";

export interface ClientGroupSearchModel extends BaseSearchModel {

}