import { BaseSearchModel } from "./baseSearchModel";

export interface ClientTypeSearchModel extends BaseSearchModel {
   
}