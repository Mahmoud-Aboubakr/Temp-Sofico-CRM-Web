export class PromtionCriteriaClientAttrCustomListModel {
    clientCode: string;
    clientId: number | null;
    clientName: string;
    clientCustomId: number | null;
    clientAttributeId: number | null;
    clientAttributeCode: string;
    clientAttributeName: string;
    isCustom: boolean | null;
}