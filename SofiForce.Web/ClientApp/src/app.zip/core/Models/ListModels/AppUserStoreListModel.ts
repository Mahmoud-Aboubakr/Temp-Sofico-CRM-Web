export class AppUserStoreListModel {
    appUserStoreId: number;
    userId: number | null;
    storeId: number | null;
    userName: string;
    storeName: string | null;
    storeCode: string;
}