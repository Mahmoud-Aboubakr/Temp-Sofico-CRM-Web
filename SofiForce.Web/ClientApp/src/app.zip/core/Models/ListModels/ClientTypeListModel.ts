export class ClientTypeListModel {
    clientTypeId: number;
    clientTypeCode: string;
    clientTypeName: string;
    icon: string;
    color: string;
    displayOrder: number | null;
    isActive: boolean | null;

}