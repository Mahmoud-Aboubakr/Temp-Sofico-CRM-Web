export class GovernerateListModel {

    governerateId: number;
    regionId: number | null;
    governerateCode: string;
    governerateName: string;
    isActive: boolean | null;
    displayOrder: number | null;
    canEdit: boolean | null;
    canDelete: boolean | null;
    color: string;
    icon: string;

}