export interface ClientLandmarkListModel {
    detaillandId: number;
    clientId: number;
    landmarkId: number;
    landmarkName: string;
}