export interface OperationRequestDetailLandmarkListModel {
    detaillandId:number;
    detailId: number;
    landmarkId: number;
    landmarkName: string;
}