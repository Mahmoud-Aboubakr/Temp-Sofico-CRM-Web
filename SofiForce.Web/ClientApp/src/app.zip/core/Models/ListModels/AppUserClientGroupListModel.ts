export class AppUserClientGroupListModel {
    appUserGroupId: number;
    userId: number | null;
    clientGroupId: number | null;
    clientGroupName: string | null;
    clientGroupCode: string;
}