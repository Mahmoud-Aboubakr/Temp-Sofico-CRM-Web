export class PromotionCriteriaAttrCustomListModel {
    customId: number | null;
    attributeId: number | null;
    itemCode: string;
    itemName: string;
}