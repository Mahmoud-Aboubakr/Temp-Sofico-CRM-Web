export class AppUserBranchListModel {
    userBranchId: number;
    branchId: number | null;
    userId: number | null;
    branchCode: string;
    branchName: string;
}