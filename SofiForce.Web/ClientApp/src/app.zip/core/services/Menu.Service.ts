import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ResponseModel } from '../Models/ResponseModels/ResponseModel';
import { BranchListModel } from '../Models/ListModels/BranchListModel';

import { BranchModel } from '../Models/EntityModels/branchModel';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  constructor() { }
  
}
