export const locale = {
    lang: 'en',
    data: {

    }
};
